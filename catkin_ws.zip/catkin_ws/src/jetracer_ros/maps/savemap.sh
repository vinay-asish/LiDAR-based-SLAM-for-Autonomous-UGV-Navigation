#!/bin/bash
rosrun map_server map_saver -f mymap
