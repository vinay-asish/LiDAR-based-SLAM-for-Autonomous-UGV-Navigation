# jetracer_ros
A ROS package of the WaveShare JetRacer ROS AI Kit. An educational AI robot based on NVIDIA Jetson Nano.

http://www.waveshare.net/shop/JetRacer-ROS-AI-Kit.htm

http://www.waveshare.com/JetRacer-ROS-AI-Kit.htm
